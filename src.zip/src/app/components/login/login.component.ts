import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private loginAuth: AuthService, private router: Router){}

  ngOnInit(): void {}

   loginForm:FormGroup = new FormGroup({
    Email: new FormControl('',[Validators.required,Validators.email]),
    Pwd: new FormControl('',[Validators.required,
      Validators.minLength(4),
      Validators.maxLength(10),
    ]),
   });

   isUserValid: boolean = false;

   loginSubmited(){
     this.loginAuth
     .loginUser([this.loginForm.value.Email, this.loginForm.value.Pwd])
     .subscribe(res => {
      if (res == 'Failure'){
        this.isUserValid = false;
        alert('Login Unsuccessful');
      } else {
        this.isUserValid = true;
        this.loginAuth.setToken(res);
        this.router.navigateByUrl('/home')
      }
     });
   }



   get Email(): FormControl {
     return this.loginForm.get('Email') as FormControl;
   }

   get Pwd(): FormControl{
      return this.loginForm.get('Pwd') as FormControl;
   }

}


