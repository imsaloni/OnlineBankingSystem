import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/Model/Models';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit{

  users: User[] = [];
  columnsToDisplay: string[] = [
    'Userid',
    'FullName',
    'Email',
    'MobileNumber',
    'AadharNumber',
    'DateOfBirth',
    'AnnualIncome',
    'Occupation',
  ];

  constructor(private authservice: AuthService) {}

  ngOnInit(): void {
    this.authservice.getAllUsers().subscribe({
      next: (res: User[]) => {
        this.users = [];
        this.users = res;
      },
      error: (err: any) => console.log(err),
    });

  }

}
