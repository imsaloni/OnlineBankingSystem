import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit{

  constructor(private authService: AuthService) {}


  ngOnInit(): void {

  }

  // registerForm = new FormGroup({
    transaction:FormGroup = new FormGroup({
    AccountNumber: new FormControl("",[
      Validators.required,

    ]),
     PayeeAccount: new FormControl("",[
      Validators.required,

    ]),
    Amount: new FormControl("",[
      Validators.required,

    ]),
    TransactionType: new FormControl("",[
      Validators.required,

    ]),

   } );

   get AccountNumber(): FormControl {
    return this.transaction.get('AccountNumber') as FormControl;
  }
  get PayeeAccount(): FormControl {
    return this.transaction.get('AccountNumber') as FormControl;
  }
  get Amount(): FormControl {
    return this.transaction.get('AccountNumber') as FormControl;
  }
  get TransactionType(): FormControl {
    return this.transaction.get('TransactionType') as FormControl;
}
}
