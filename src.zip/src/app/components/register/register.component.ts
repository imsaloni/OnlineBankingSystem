import { NonNullAssert } from '@angular/compiler';
import { Component, OnInit} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  repeatPass: string ='none';

  displayMsg: string ='';
  isAccountCreated: boolean = false;
  constructor(private authService: AuthService) {}


  ngOnInit(): void {

  }

  // registerForm = new FormGroup({
    registerForm:FormGroup = new FormGroup({
    FullName: new FormControl("",[
      Validators.required,
      Validators.pattern("[a-zA-Z].*")
    ]),

    Mobile: new FormControl("",[
      Validators.required,
      Validators.minLength(10),
      Validators.maxLength(10),
      Validators.pattern("[0-9]*")
    ]),

    Email: new FormControl("", [
     Validators.required,
     Validators.email]),

    AadharNumber: new FormControl("", [
     Validators.required,Validators.pattern("[0-9]*")
    ]),

    DateOfBirth: new FormControl("", [
     Validators.required,
    ]),

    Address: new FormControl("", [
      Validators.required,
    ]),

    Occupation: new FormControl("", [
      Validators.required,
    ]),

    AnnualIncome: new FormControl("",[
      Validators.required,
    ]),
    Pwd: new FormControl("", [
      Validators.required,
      Validators.minLength(4),
      Validators.maxLength(10),
    ]),
    Rpwd: new FormControl("",[
      Validators.required,
      Validators.minLength(4),
      Validators.maxLength(10),
    ]),


  });

  registerSubmited(){
    if(this.Pwd.value == this.Rpwd.value){
     console.log(this.registerForm.valid);
     this.repeatPass = 'none';

     this.authService.
      registerUser([
        this.registerForm.value.FullName,
        this.registerForm.value.Mobile,
        this.registerForm.value.Email,
        this.registerForm.value.AadharNumber,
        this.registerForm.value.DateOfBirth,
        this.registerForm.value.Address,
        this.registerForm.value.Occupation,
        this.registerForm.value.AnnualIncome,
        this.registerForm.value.Pwd,
      ])
      .subscribe((res => {
        if(res == 'Success'){
          this.displayMsg = 'Account created Succssfully!';
          this.isAccountCreated = true;
        }else if(res == 'AlreadyExist'){
          this.displayMsg ='Account Already exist. try another Email';
          this.isAccountCreated = false;

        }else{
          this.displayMsg ='Something went wrong';
          this.isAccountCreated = false;
        }
     }));

    }else{
     this.repeatPass="inline"
    }

   }


   get FullName(): FormControl {
     return this.registerForm.get("FullName") as FormControl;
   }

   get Mobile(): FormControl {
     return this.registerForm.get("Mobile") as FormControl;
   }



   get Email(): FormControl {
     return this.registerForm.get("Email") as FormControl;
   }

   get AadharNumber(): FormControl {
     return this.registerForm.get("AadharNumber") as FormControl;
   }

   get DateOfBirth(): FormControl {
     return this.registerForm.get("DateOfBirth") as FormControl;

   }

   get Address(): FormControl {
     return this.registerForm.get("Address") as FormControl;

   }

   get Occupation(): FormControl {
     return this.registerForm.get("Occupation") as FormControl;

   }

   get AnnualIncome (): FormControl {
     return this.registerForm.get("AnnualIncome") as FormControl;

   }

   get Pwd(): FormControl {
     return this.registerForm.get("Pwd") as FormControl;

   }

   get Rpwd(): FormControl {
     return this.registerForm.get("Rpwd") as FormControl;

   }
  }
