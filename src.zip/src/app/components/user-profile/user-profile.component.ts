import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService} from 'src/app/services/auth.service';
import { RegisterComponent } from 'src/app/components/register/register.component';
import { JwtHelperService } from '@auth0/angular-jwt';

export interface TableElement{
  name: string;
  value: string;
}
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit{
  dataSource: TableElement[] = [];
  columns: string[] =['name','value'];


  constructor(private api: AuthService){}
  ngOnInit(){
  let user = this.api.loadCurrentUser();
   this.dataSource=[
      {name: "FullName", value: user?.FullName + '' },
      {name: "Mobile", value: user?.MobileNumber +""},
      {name: "Email", value: user?.Email ?? "" },
      {name: "AadharNumber", value:user?.AadharNumber +""},
      {name: "DateOfBirth", value:user?.DateOfBirth+""},
      {name: "Address", value:user?.Address +""},
      {name: "Occupation", value:user?.Occupation},
      {name: "AnnualIncome", value:user?.AnnualIncome+""},

    ];
  }







}



