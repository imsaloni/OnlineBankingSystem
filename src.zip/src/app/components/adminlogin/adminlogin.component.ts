import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { FormControl, FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  constructor(private loginAuth: AuthService, private router: Router){}

  ngOnInit(): void {}

   AdminloginForm:FormGroup = new FormGroup({
    Email: new FormControl('',[Validators.required,Validators.email]),
    Pwd: new FormControl('',[Validators.required,
      Validators.minLength(4),
      Validators.maxLength(10),
    ]),
   });

   isAdminValid: boolean = false;

   AdminloginSubmited(){
     this.loginAuth
     .loginUser([this.AdminloginForm.value.Email, this.AdminloginForm.value.Pwd])
     .subscribe((res => {
      if (res == 'Failure'){
        this.isAdminValid = false;
        alert('Unsuccessful');
      } else {
        this.isAdminValid = true;

        this.router.navigateByUrl('/adminlogin')
      }
     }));
   }



   get Email(): FormControl {
     return this.AdminloginForm.get('Email') as FormControl;
   }

   get Pwd(): FormControl{
      return this.AdminloginForm.get('Pwd') as FormControl;
   }

}


