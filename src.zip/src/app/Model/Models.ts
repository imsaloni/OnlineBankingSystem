export interface User {
  Userid: number;
  FullName: string;
  MobileNumber: string;
  Email:string;
  AadharNumber:string;
  DateOfBirth:string;
  Address:string;
  AnnualIncome:string;
  Occupation:string;
}
