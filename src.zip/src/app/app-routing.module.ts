import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './components/admin/admin.component';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';
import { FundtransferComponent } from './components/fundtransfer/fundtransfer.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { RegisterComponent } from './components/register/register.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { AuthGuard } from './services/auth.guard';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },

  {
  path: 'register',
  component: RegisterComponent
  },
  {
    path: 'userprofile',
    component: UserProfileComponent
    },
    {
      path: 'admin',
      component: AdminComponent,

      },

      {
        path: 'fundtransfer',
        component: FundtransferComponent
        },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'adminlogin',
    component: AdminloginComponent,

  },

  {
    path: '**',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
