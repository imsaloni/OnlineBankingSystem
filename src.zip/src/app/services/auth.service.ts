import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { BehaviorSubject, map } from 'rxjs';
import { UserProfileComponent } from '../components/user-profile/user-profile.component';
import { User } from '../Model/Models';


@Injectable({
  providedIn: 'root',
})
export class AuthService {
  Admin() {
    throw new Error('Method not implemented.');
  }

  constructor(private http:HttpClient) { }

  currentUser: BehaviorSubject<any> = new BehaviorSubject(null);

  baseServerUrl = 'https://localhost:44392/api/';

  jwtHelperService = new JwtHelperService();

  registerUser(user: Array<String>){
    return this.http.post(this.baseServerUrl + 'User/CreateUser',{
      FullName : user[0],
      MobileNumber : user[1],
      Email : user[2],
      AadharNumber : user[3],
      DateOfBirth : user[4],
      Address : user[5],
      Occupation : user[6],
      AnnualIncome : user[7],
      pwd : user[8]
    },
    {
    responseType : 'text',
     }
   );
 }

  loginUser(loginInfo: Array<string>){
    return this.http.post(this.baseServerUrl + 'User/LoginUser', {
    Email: loginInfo[0],
    pwd: loginInfo[1],
    },
    {
      responseType: 'text',
    }
    );
  }

  Adminlogin(loginInfo: Array<string>){
    return this.http.post(this.baseServerUrl + 'User/Adminlogin', {
    Email: loginInfo[0],
    pwd: loginInfo[1],
    },
    {
      responseType: 'text',
    }
    );
  }


  setToken(token: string){
    localStorage.setItem("access_token", token);
    this.loadCurrentUser();
   }

  loadCurrentUser(){
    const token = localStorage.getItem("access_token");
    const userInfo = token != null ? this.jwtHelperService.decodeToken(token) : null;
    const data = userInfo ? {
      id: userInfo.id,
      FullName: userInfo.FullName,
      MobileNumber: userInfo.MobileNumber,
      Email: userInfo.Email,
      AadharNumber: userInfo.AadharNumber,
      DateOfBirth: userInfo.DateOfBirth,
      Address: userInfo.Address,
      Occupation: userInfo.Occupation,
      AnnualIncome: userInfo.AnnualIncome

    } : null;
    this.currentUser.next(data);
    return data;
  }


  isLoggedin(): boolean {
    return localStorage.getItem("access_token") ? true : false;
  }

  removeToken(){
    localStorage.removeItem("access_token");
  }

  getAllUsers() {
    return this.http.get<User[]>(this.baseServerUrl + 'User/getAllUsers').pipe(
      map((users) =>
        users.map((user: User) => {
          let temp: User = user;

          return temp;
        })
      )

    );
  }

}
